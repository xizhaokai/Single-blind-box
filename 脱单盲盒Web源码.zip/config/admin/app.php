<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

return [
    // 是否自动转换URL中的控制器和操作名
    'url_convert'            => false,
    
    "auth_login" => "/admin/login/index",
    
    
    
];