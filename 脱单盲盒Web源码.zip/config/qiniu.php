<?php
/**
 * Created by PhpStorm.
 * User: wujingtao
 * Date: 2021/9/25
 * Time: 10:22
 */

return [
    'bucket' => env("QINIU_BUCKET"),
    'accessKey' => env("QINIU_ACCESSKEY"),
    'secretKey' => env("QINIU_SECRETKEY"),
    'domain' => env("QINIU_DOMAIN")
];