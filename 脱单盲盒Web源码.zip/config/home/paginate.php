<?php

return [
    'type'     => 'app\common\lib\Pager',
    'list_rows' => 30,

    
    
];