<?php

return [
    'lang' => 'cn',
    
    'empty_controller'       => '',
    
    
    // URL伪静态后缀
    'url_html_suffix'        => '',
];