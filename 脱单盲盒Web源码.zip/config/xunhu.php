<?php

//return [
//    'appid' => '201906140042',
//    'appsecret' => '3ce2784b7a027da27f123aeef5b1d526',
//    'my_plugin_id' => 'my-plugins-id',
//];
return [
    'appid' => '',
    'appsecret' => '',
    'my_plugin_id' => 'my-plugins-id',
];