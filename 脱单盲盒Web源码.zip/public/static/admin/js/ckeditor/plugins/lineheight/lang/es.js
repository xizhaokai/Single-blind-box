CKEDITOR.plugins.setLang('lineheight','es', {
    title: 'Altura de Línea'
} );
