<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

return [
    
    //输出替换
    'tpl_replace_string'  =>  [
        '__STATIC__'=>'/static',
        
        "__PUBLIC__" => "/static/admin",
        '__CSS__' => '/static/admin/css',
        '__IMAGES__' => '/static/admin/images',
        '__JS__' => '/static/admin/js',
        '__BOOTSTRAP__' => '/static/admin/js/bootstrap',
        
        '__UPLOAD__'    => '/uploads',
    ],
    
];